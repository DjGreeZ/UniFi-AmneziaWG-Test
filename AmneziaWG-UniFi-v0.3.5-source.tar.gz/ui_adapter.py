"""Adapt the active Network UI by structure, never by a version/hash allowlist.

Vendor source stays on the appliance. An installation records its exact originals
and generated hashes for later maintenance/removal; hashes are not compatibility
requirements. Unsupported structural changes fail before any system file write.
"""
import hashlib
import json
from pathlib import Path
import re
from portal_compatibility import stock_portal, patch_portal

BASE = '/usr/lib/unifi/webapps/ROOT/app-unifi'
PORTAL = '/usr/share/unifi-core/app/node_modules/@ubnt/unifi-portal/dist/local/index.html'
MARKER = '/* AWG-NATIVE-ADAPTER */'
IDENT = r'[A-Za-z_$][\w$]*'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('Изменилась структура интерфейса: ' + before[:80])
    return text.replace(before, after, 1)


def unique(pattern, text):
    matches = list(re.finditer(pattern, text))
    if len(matches) != 1:
        raise ValueError('Не найден однозначный компонент интерфейса: ' + pattern[:90])
    return matches[0]


def inject_modules(text, modules):
    anchor = unique(r'\.push\(\[\[[\d,]+\],\{', text).group()
    for number in (790001, 790002, 790003):
        if re.search(r'\b' + str(number) + r'\(', text):
            raise ValueError('Номер модуля панели уже занят.')
    code = ''.join(str(790001 + n) + '(e,t,i){' + body + '},'
                   for n, body in enumerate(modules))
    return MARKER + once(text, anchor, anchor + code)


def patch10(originals, modules):
    s = originals['settings.js'].decode()
    anchor = '{id:l.iB.VPN_CLIENT,path:l.iB.VPN_CLIENT,component:u.A},'
    s = once(s, anchor, anchor + '{id:"amnezia",path:"amnezia",component:i(790001).A},')
    anchor = '(0,s.jsx)(g.A,{title:(0,s.jsx)(p.sA,{id:"COMMON_SITE_TO_SITE_VPN"})'
    card = '(0,s.jsx)(g.A,{title:"AmneziaWG Client",description:"Подключения AmneziaWG и резервирование.",to:o.replace(/client$/, "amnezia"),isSelected:"amnezia"===t,connector:"amnezia"===t?(0,s.jsx)(M.A,{}):null}),'
    s = once(s, anchor, card + anchor)
    anchor = 'renderCell:({protocol:e,enabled:t})=>(0,n.jsx)(o.A,{color:t?"inherit":"disabled",children:(0,n.jsx)(l.sA,{id:e||"COMMON_FALLBACK"})})'
    after = 'renderCell:({protocol:e,enabled:t,network:w})=>(0,n.jsx)(o.A,{color:t?"inherit":"disabled",children:/^amneziawg-[1-4]\\.conf$/.test(w?.wireguard_client_configuration_filename||"")?"AmneziaWG":(0,n.jsx)(l.sA,{id:e||"COMMON_FALLBACK"})})'
    return {'settings.js': inject_modules(once(s, anchor, after), modules).encode()}


# Contracts for the native components used by the panel. These IDs are generated
# from source paths, not release numbers. Validate the required exports as well as
# semantic markers, so an unknown/colliding module cannot silently be used.
BINDINGS11 = {
    602086: (602086, (), ('exports=',)),
    977872: (977872, ('wA', 'd4'), ()),
    997872: (276328, ('A',), ('stateIcon', 'variant')),
    206725: (648461, ('A',), ('arrowSize', 'onChange', 'placeholder')),
    502129: (947331, ('A',), ('.Link', 'themeName')),
    553732: (836274, ('Sk', 'VS', 'ux', 'wR'), ('ID_FIELD', 'MODEL')),
    197571: (34677, ('Zl',), ('vpn',)),
    623568: (737272, ('EO',), ('trafficroutes',)),
    936069: (417175, ('iE',), ('target_devices', 'network_id')),
    581814: (112248, ('rR', 'hS', 'dY'), ('VPN_CLIENT="vpn-client"', 'FILE="file"')),
    794721: (483195, ('EF',), ('WIREGUARD_CLIENT',)),
    43506: (70250, ('A',), ('URLSearchParams',)),
    418905: (418905, ('u',), ('useContext',)),
    11203: (892381, ('Ay',), ('desktop-color-ublue-06-dark',)),
    309130: (583428, ('kc',), ()),
    742220: (175446, ('Ch',), ('WIREGUARD_CLIENT',)),
    909452: (166724, ('A',), ('speedTestData', 'animationBuffer')),
    122109: (641860, ('A',), ('Icon:', 'desktop-color-aqua-06-')),
    964978: (486843, ('A',), ('Icon:', 'desktop-color-purple-06-')),
    419284: (670274, ('b_',), ('hsla',)),
}

# The split UI also has a newer bundle layout (observed in 11.1.47). The
# renderer/actions retain their contracts, but module IDs and chunk placement
# changed. Select by validated structure, not by a maximum Network version.
BINDINGS11_1 = {
    602086: (902503, (), ('exports=',)),
    977872: (828193, ('wA', 'd4'), ('react.element',)),
    997872: (664439, ('A',), ('stateIcon', 'variant')),
    206725: (60483, ('A',), ('arrowSize', 'onChange', 'placeholder')),
    502129: (561928, ('A',), ('.Link', 'themeName')),
    553732: (974983, ('Sk', 'VS', 'ux', 'wR'), ('idField:', 'remove_references=true')),
    197571: (47674, ('Zl',), ('vpn',)),
    623568: (9794, ('EO',), ('trafficroutes',)),
    936069: (949340, ('iE',), ('target_devices', 'network_id')),
    581814: (458001, ('rR', 'hS', 'dY'), ('VPN_CLIENT="vpn-client"', 'FILE="file"')),
    794721: (386856, ('EF',), ('WIREGUARD_CLIENT',)),
    43506: (834967, ('A', 'N'), ('URLSearchParams', 'useCallback', 'split("/")')),
    418905: (541992, ('u',), ('useContext',)),
    11203: (29191, ('Ay',), ('desktop-color-ublue-06-dark',)),
    309130: (526393, ('kc',), ('desktop-spacing-base-02',)),
    909452: (298291, ('A',), ('speedTestData', 'animationBuffer')),
    122109: (297933, ('A',), ('Icon:', 'desktop-color-aqua-06-')),
    964978: (556222, ('A',), ('Icon:', 'desktop-color-purple-06-')),
    419284: (378929, ('b_',), ('hsla',)),
}


def has_export(body, name):
    # The newer bundler emits both getter objects and [name, kind, value]
    # arrays. Match the requested name exactly in either representation.
    name = re.escape(name)
    return bool(re.search(r'\b' + name + r':\s*\(\)\s*=>|"' + name + r'",[01],', body))


def validate_contract(index, number, exports=(), markers=()):
    body = index.get(number, ('', '', ''))[0]
    if not body or any(not has_export(body, x) for x in exports) or any(x not in body for x in markers):
        raise ValueError('Изменился необходимый компонент Network: ' + str(number))
    return body


def split_bindings(index):
    # The React wrapper is the profile discriminator, checked again below.
    bindings = BINDINGS11 if 602086 in index else BINDINGS11_1
    for number, exports, markers in bindings.values():
        validate_contract(index, number, exports, markers)
    if bindings is BINDINGS11_1:
        validate_contract(index, 368340, (), ('createElement=', 'useState=', 'useContext='))
        validate_contract(index, 186815, ('A2', 'gI', 'RR'), ('networkconf', '"_id"'))
        # Network now inlines the native active-client limit instead of
        # exporting Ch. Refuse a changed limit instead of silently guessing.
        validate_contract(index, 135502, ('A',),
                          ('SETTINGS_VPN_CLIENT_LIMIT_REACHED', 'values:{max:8}', 'F<8'))
    return bindings


def active_bundle_files(base, metadata):
    """Ignore chunks retained from an older Network installation.

    Named entries come from the active manifest; split chunks must have their
    content hash in the active webpack entry's filename map.
    """
    entry = metadata.get('uiIndex', '')
    if not re.fullmatch(r'react/js/swai\.[A-Za-z0-9]+\.js', entry):
        raise ValueError('Не поддерживается точка загрузки интерфейса Network.')
    text = (base / entry).read_text()
    hashes = set(re.findall(r'"([a-fA-F0-9]{16,64})"', text))
    named = set(metadata.get('prefetch', [])) | {entry}
    files = {}
    for path in (base / 'react/js').glob('*.js'):
        match = re.fullmatch(r'.+\.([A-Za-z0-9]+)\.js', path.name)
        if 'react/js/' + path.name in named or (match and match[1] in hashes):
            files[path.name] = text if 'react/js/' + path.name == entry else path.read_text()
    return files


def dependency_chunks(index, files, roots):
    """Collect the native chunks needed before evaluating our injected panel.

    Components that were bundled in swai now live in separate chunks. Follow
    literal require calls only; do not execute the downloaded vendor source.
    The swai entry itself is already loaded by UniFi and has no chunk wrapper.
    """
    pending, visited, chunks = list(roots), set(), set()
    while pending:
        number = pending.pop()
        if number in visited:
            continue
        visited.add(number)
        if number not in index:
            raise ValueError('Не найдена зависимость Network: ' + str(number))
        body, filename, loader = index[number]
        match = re.search(r'\.push\(\[\[([\d,]+)\],\{', files[filename])
        if match:
            chunks.update(int(x) for x in match[1].split(','))
        elif not filename.startswith('swai.'):
            raise ValueError('Не определён файл загрузки Network: ' + filename)
        if loader:
            pending.extend(int(x) for x in re.findall(r'\b' + re.escape(loader) + r'\((\d+)\)', body))
    return sorted(chunks)


def module_index(files):
    # Webpack emits numeric object methods. We only inspect text, never execute
    # vendor code during installation. Export and semantic checks follow below.
    pattern = re.compile(r'(?<=[{,])(\d+)\((' + IDENT + '(?:,' + IDENT + r'){0,2})\)\{')
    result = {}
    for filename, text in files.items():
        matches = list(pattern.finditer(text))
        for pos, match in enumerate(matches):
            end = matches[pos + 1].start() if pos + 1 < len(matches) else len(text)
            args = match[2].split(',')
            result[int(match[1])] = (text[match.end():end], filename, args[-1] if len(args) == 3 else '')
    return result


def adapt_modules11(modules, files):
    index = module_index(files)
    bindings = split_bindings(index)
    panel, settings, stats = modules
    panel = once(panel, 'NativeLayout=i(794612).A', 'NativeLayout=({children})=>children')
    panel = once(panel, ', Routes=i(969288)', '')
    panel = once(panel, 'policyPath=usePath(`${Routes.p7}?${Routes.Rp}=${Routes.HJ}`)',
                 'policyPath=usePath()("[site]/settings/policy-table")')
    if bindings is BINDINGS11_1:
        panel = once(panel, 'i(742220).Ch', '8')
        chart_chunks = dependency_chunks(index, files, [bindings[909452][0]])
    else:
        chart_chunks = [59956, 25557, 44139]
    stats = once(stats, 'i.e(90645)', 'Promise.all(' + json.dumps(chart_chunks) + '.map(x=>i.e(x)))')
    mapping = {old: new[0] for old, new in bindings.items()}
    return [re.sub(r'\bi\((\d+)\)', lambda m: 'i(' + str(mapping.get(int(m[1]), int(m[1]))) + ')', code)
            for code in (panel, settings, stats)]


def validate_modules10(files):
    index = module_index(files)
    contracts = {old: exports for old, (_, exports, _) in BINDINGS11.items()}
    contracts.update({794612: ('A',), 969288: ('p7', 'Rp', 'HJ')})
    for number, exports in contracts.items():
        body = index.get(number, ('', '', ''))[0]
        if not body or any(not re.search(r'\b' + x + r':\s*\(\)\s*=>', body) for x in exports):
            raise ValueError('Изменился необходимый компонент Network: ' + str(number))


def patch11(originals, modules, files):
    modules = adapt_modules11(modules, files)
    router = originals['settings.js'].decode()
    route = unique(r'\{id:"\[site\]/settings/vpn/client",routerPath:":site/settings/vpn/client",bracketPath:"\[site\]/settings/vpn/client",page:(' + IDENT + r'),layouts:\[[^\]]+\],ancestorConfigs:\[[^\]]+\]\}', router)
    lazy = unique(re.escape(route[1]) + r'=\(0,(' + IDENT + r')\.lazy\)\(\(\)=>((?:Promise\.all\(\[[^\]]+\]\)|' + IDENT + r'\.e\(\d+\))\.then\((?:' + IDENT + r'\.bind\(' + IDENT + r',\d+\)|\(\)=>' + IDENT + r'\(\d+\))\))\)', router)
    require = unique(r'(\w+)\.r\(\w+\),\w+\.d\(\w+,\{default:', router)[1]
    index = module_index(files)
    bindings = split_bindings(index)
    load = lazy[2]
    if bindings is BINDINGS11_1:
        chunks = dependency_chunks(index, files, [x[0] for x in bindings.values()])
        load = 'Promise.all([' + load + ',...' + json.dumps(chunks) + '.map(x=>' + require + '.e(x))])'
    newroute = route[0].replace('/vpn/client', '/vpn/amnezia').replace('page:' + route[1] + ',',
        'page:(0,' + lazy[1] + '.lazy)(()=>'+load+'.then(()=>({default:' + require + '(790001).A}))),')
    router = once(router, route[0], route[0] + ',' + newroute)
    layout = originals['vpn-layout.js'].decode()
    card = unique(r'\(0,(' + IDENT + r')\.jsx\)\((' + IDENT + r')\.A,\{title:\(0,\1\.jsx\)\(' + IDENT + r'\.sA,\{id:"COMMON_SITE_TO_SITE_VPN"\}\)', layout)
    newcard = '(0,'+card[1]+'.jsx)('+card[2]+'.A,{title:"AmneziaWG Client",description:"Подключения AmneziaWG и резервирование.",to:"[site]/settings/vpn/amnezia"}),'
    layout = once(layout, card[0], newcard + card[0])
    # Keep the section selection and spacing aligned with the native sidebar.
    layout = once(layout, '["server","client","siteToSite"]', '["server","client","siteToSite","amnezia"]')
    layout = once(layout, 'siteToSite:"[site]/settings/vpn/site-to-site"', 'siteToSite:"[site]/settings/vpn/site-to-site",amnezia:"[site]/settings/vpn/amnezia"')
    client = originals['vpn-client.js'].decode()
    cell = unique(r'children:\(0,(' + IDENT + r')\.jsx\)\((' + IDENT + r')\.sA,\{id:(' + IDENT + r')\.original\.protocol\|\|"COMMON_FALLBACK"\}\)', client)
    client = once(client, cell[0], 'children:/^amneziawg-[1-4]\\.conf$/.test('+cell[3]+'.original.network?.wireguard_client_configuration_filename||"")?"AmneziaWG":'+cell[0][9:])
    return {'settings.js': inject_modules(router, modules).encode(),
            'vpn-layout.js': (MARKER + layout).encode(), 'vpn-client.js': (MARKER + client).encode()}


def discover(package, root, filesystem=Path('/')):
    base = filesystem / BASE.lstrip('/')
    metadata = json.loads((base / 'manifest.json').read_text())
    prefetch = metadata.get('prefetch', [])
    def asset(name):
        matches = [p for p in prefetch if re.fullmatch(r'react/js/' + re.escape(name) + r'\.[A-Za-z0-9]+\.js', p)]
        if len(matches) != 1:
            raise ValueError('Не найден активный файл интерфейса ' + name)
        return BASE + '/' + matches[0]
    targets = {'settings.js': asset('settings')}
    modern = any(re.fullmatch(r'react/js/settings-vpn-layout\.[A-Za-z0-9]+\.js', p) for p in prefetch)
    if modern:
        targets.update({'vpn-layout.js': asset('settings-vpn-layout'), 'vpn-client.js': asset('settings-vpn-client')})
    targets['portal-index.html'] = PORTAL
    previous = json.loads((root / 'manifest.json').read_text()) if (root / 'manifest.json').is_file() else []
    originals = {}
    for source, target in targets.items():
        current = (filesystem / target.lstrip('/')).read_bytes()
        old = next((item for item in previous if item['target'] == target), None)
        if old and sha(current) in old['allowed'] and sha(current) != old['original']:
            current = (root / 'backup' / old['source']).read_bytes()
            if sha(current) != old['original']:
                raise ValueError('Повреждена исходная резервная копия ' + source)
        if MARKER.encode() in current or (source.endswith('.js') and b'790001(e,t,i)' in current):
            raise ValueError('Нет исходной резервной копии для установленного патча ' + source)
        originals[source] = current
    portal = originals['portal-index.html']
    if b'portal-root' not in portal or b'UNIFI_OS_MANIFEST' not in portal:
        raise ValueError('Изменена структура страницы загрузки UniFi OS.')
    originals['portal-index.html'] = stock_portal(portal)
    modules = [(package / name).read_text() for name in ('panel-module.js', 'settings-panel.js', 'statistics-panel.js')]
    files = active_bundle_files(base, metadata)
    if modern:
        patched = patch11(originals, modules, files)
    else:
        validate_modules10(files)
        patched = patch10(originals, modules)
    patched['portal-index.html'] = patch_portal(originals['portal-index.html'])
    manifest = [{'target': targets[name], 'source': name, 'original': sha(data),
                 'allowed': [sha(data), sha(patched[name])]} for name, data in originals.items()]
    return manifest, originals, patched
