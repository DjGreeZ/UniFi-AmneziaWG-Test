"""Prepare and validate every UI change before changing any vendor file."""
import json
import secrets
import shutil
import sys
from pathlib import Path
from compatibility import check_system, ui_context
from ui_adapter import discover, sha


def render_route(template, manifest):
    import re
    # Compatibility with the older two-location template; generate one rule for
    # every patched JS chunk, including the split VPN chunks in Network 11.
    template = re.sub(r'location = /app-assets/network/react/js/@@(?:FRONTEND|SETTINGS)@@ \{.*?\n\}', '', template, flags=re.S)
    locations = []
    for item in manifest:
        if not item['source'].endswith('.js'):
            continue
        target = item['target']
        if not re.fullmatch(r'/usr/lib/unifi/webapps/ROOT/app-unifi/react/js/[A-Za-z0-9_.-]+\.js', target):
            raise ValueError('Недопустимый путь интерфейса')
        locations.append('''location = /app-assets/network/react/js/%s {
    include /usr/share/unifi-core/http/cors.conf;
    include /usr/share/unifi-core/http/security.conf;
    include /usr/share/unifi-core/http/auth.conf;
    include /usr/share/unifi-core/http/proxy.conf;
    alias %s;
    expires off;
    add_header Cache-Control "no-store" always;
}''' % (Path(target).name, target))
    return template.replace('# AWG-NATIVE-END', '\n'.join(locations) + '\n# AWG-NATIVE-END')


def atomic(path, data, mode=0o600):
    temp = path.with_name(path.name + '.tmp')
    temp.write_bytes(data)
    temp.chmod(mode)
    temp.replace(path)


def prepare(package, root, check_only=False, filesystem=Path('/'), versions=None):
    os_version, network_version = versions or check_system()
    manifest, originals, patched = discover(package, root, filesystem)
    context = ui_context(manifest, filesystem)
    route = render_route((package / 'route.conf.template' if (package / 'route.conf.template').exists() else package / 'route.conf').read_text(), manifest)
    # Allow the previous, verified patch while maintain transitions to the new
    # generated output. This is an installed checksum, not a compatibility gate.
    previous = json.loads((root / 'manifest.json').read_text()) if (root / 'manifest.json').exists() else []
    for item in manifest:
        old = next((x for x in previous if x['target'] == item['target'] and x['original'] == item['original']), None)
        current = sha((filesystem / item['target'].lstrip('/')).read_bytes())
        if old and current in old['allowed'] and current not in item['allowed']:
            item['allowed'].append(current)
    if check_only:
        print(f'Совместимость подтверждена: OS {os_version} / Network {network_version}.')
        return manifest
    root.mkdir(mode=0o755, parents=True, exist_ok=True)
    root.chmod(0o755)
    if previous:
        identity = sha(json.dumps(previous, sort_keys=True).encode())[:16]
        history = root / 'ui-history' / identity
        if not history.exists():
            history.mkdir(mode=0o700, parents=True)
            for path in ('backup', 'manifest.json', 'ui-build.json', 'route.conf'):
                source = root / path
                if source.is_dir():
                    shutil.copytree(source, history / path)
                elif source.is_file():
                    shutil.copy2(source, history / path)
    backup = root / 'backup'
    backup.mkdir(mode=0o700, exist_ok=True)
    backup.chmod(0o700)
    for name, original in originals.items():
        atomic(backup / name, original)
        atomic(root / name, patched[name], 0o644)
    atomic(root / 'route.conf', route.encode(), 0o644)
    atomic(root / 'manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())
    atomic(root / 'ui-build.json', json.dumps({'os': os_version, 'network': network_version, 'context': context}).encode())
    atomic(root / 'asset-revision', (secrets.token_hex(8) + '\n').encode())
    return manifest


if __name__ == '__main__':
    try:
        prepare(Path(__file__).resolve().parent, Path('/data/awg-native'), '--check' in sys.argv)
    except (ValueError, OSError, KeyError) as error:
        raise SystemExit(str(error))
